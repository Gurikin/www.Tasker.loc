<?php
interface IController {}