<h2>Добавление сотрудника</h2>

<?php
    foreach ($this->user as $u=>$r) {
        echo "New user $u : $r";
    }
?>