<?php
    echo $this->msg;
?>