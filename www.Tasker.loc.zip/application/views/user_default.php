<div class="jumbotron">
    <h1>TASKER</h1>
</div>
<div> <?php echo "<h3>Добрый день, ". $this->user->firstName . " " . $this->user->middleName . "</h3>";?></div>

<!--<div class="tab-content">
    <div id="homepage" class="tab-pane fade in active">
        <h3>Панель 1</h3>
        <p>Содержимое Домашней страницы</p>
    </div>
    <div id="about" class="tab-pane fade">
        <h3>Панель 2</h3>
        <p>Содержимое страницы about</p>
    </div>
    <div id="task_list" class="tab-pane fade">
        <h3>Панель 3</h3>
        <p>Список задач</p>
    </div>
    <div id="user_list" class="tab-pane fade">
        <h3>Панель 4</h3>
        <ol>
            <?php
                foreach ($this->list as $user => $role) {
                    echo "<li>$user : $role</li>";
                }
                
            ?>
        </ol>
    </div>
</div>-->